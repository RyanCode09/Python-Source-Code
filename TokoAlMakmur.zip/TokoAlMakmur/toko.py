import tkinter as tk
from libs import tambah_barang, Edit_Harga, hapus_barang, cek_stok,draw_gradient

# Koneksi ke database
def toko():
    # Buat jendela
    root = tk.Tk()
    root.title("Toko Al-Makmur")
    width, height = 600, 500
    root.geometry(f"{width}x{height}")
    root.attributes("-toolwindow", True)

    # Buat canvas dan gradient
    canvas = tk.Canvas(root, width=width, height=height, highlightthickness=0)
    canvas.pack(fill="both", expand=True)
    draw_gradient(canvas, width, height, "#0000ff", "#ffffff")

    # Tambahkan widget ke canvas
    label = canvas.create_text(width//2, 30, text="Toko Sembako Al-Makmur", font=("Arial", 17, "bold"), fill="white")

    btn1 = tk.Button(root, text="1. Tambah Barang", command=tambah_barang, width=25)
    canvas.create_window(width//2, 70, window=btn1)

    btn2 = tk.Button(root, text="2. Ubah Harga", command=Edit_Harga, width=25)
    canvas.create_window(width//2, 105, window=btn2)

    btn3 = tk.Button(root, text="3. Hapus Barang", command=hapus_barang, width=25)
    canvas.create_window(width//2, 140, window=btn3)

    btn4 = tk.Button(root, text="4. Cek Stok", command=cek_stok, width=25)
    canvas.create_window(width//2, 175, window=btn4)

    btn_exit = tk.Button(root, text="Keluar", command=root.destroy, bg="red", fg="white", width=30)
    canvas.create_window(width//2, 220, window=btn_exit)

# Jalankan aplikasi
    root.mainloop()
if __name__ == '__main__':
    toko()