from tkinter import messagebox, simpledialog
import mysql.connector

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="tokoalmakmur"
)
cursor = db.cursor()

# Fungsi untuk menggambar gradient
def draw_gradient(canvas, width, height, color1, color2):
    r1, g1, b1 = canvas.winfo_rgb(color1)
    r2, g2, b2 = canvas.winfo_rgb(color2)

    r_ratio = (r2 - r1) / height
    g_ratio = (g2 - g1) / height
    b_ratio = (b2 - b1) / height

    for i in range(height):
        nr = int(r1 + (r_ratio * i))
        ng = int(g1 + (g_ratio * i))
        nb = int(b1 + (b_ratio * i))
        color = f'#{nr >> 8:02x}{ng >> 8:02x}{nb >> 8:02x}'
        canvas.create_line(0, i, width, i, fill=color)

# Fungsi Tambah, Edit, Hapus, Cek Barang (sama seperti sebelumnya)
def Edit_Harga():
    barang_edit = simpledialog.askstring("Input", "Masukkan Nama Barang yang Akan Diubah:")
    harga_baru = simpledialog.askinteger("Input", "Masukkan Harga Baru:")
    if barang_edit and harga_baru:
        sql = "UPDATE barang_masuk SET harga = %s WHERE nama_barang = %s"
        cursor.execute(sql, (harga_baru, barang_edit))
        db.commit()
        if cursor.rowcount > 0:
            messagebox.showinfo("Sukses", f"Harga barang '{barang_edit}' berhasil diubah.")
        else:
            messagebox.showinfo("Gagal", "Barang tidak ditemukan.")
    else:
        messagebox.showwarning("Peringatan", "Semua input harus diisi.")

def tambah_barang():
    nama = simpledialog.askstring("Input", "Masukkan Nama Barang:")
    tanggal = simpledialog.askstring("Input", "Masukkan Tanggal Masuk (YYYY-MM-DD):")
    harga = simpledialog.askstring("Input", "Masukan Harga Yang Akan Dijual: ")
    if nama and tanggal and harga:
        query = "INSERT INTO barang_masuk (nama_barang, tanggal, harga) VALUES (%s, %s, %s)"
        cursor.execute(query, (nama, tanggal, harga))
        db.commit()
        messagebox.showinfo("Sukses", "Barang berhasil ditambahkan.")
    else:
        messagebox.showwarning("Gagal", "Data tidak boleh kosong.")

def hapus_barang():
    nama = simpledialog.askstring("Hapus Barang Dari Stok", "Masukkan Nama Barang yang akan dihapus:")
    confrim_delete = messagebox.askyesno("Yakin Ingin MengHapus", "Oke(Hapus) Cancel(Tidak)")
    if confrim_delete:
            if nama:
                cursor.execute("DELETE FROM barang_masuk WHERE nama_barang = %s", (nama,))
                db.commit()
                if cursor.rowcount > 0:
                    messagebox.showinfo("Berhasil", f"{cursor.rowcount} barang dihapus.")
                else:
                    messagebox.showinfo("Info", "Barang tidak ditemukan.")
            else:
                messagebox.showwarning("Gagal", "Nama barang tidak boleh kosong.")
    else:
            messagebox.showwarning("Dibatalkan", "Anda Membatalkan Menghapus Barang")
def cek_stok():
    cursor.execute("SELECT nama_barang, tanggal, harga FROM barang_masuk")
    hasil = cursor.fetchall()
    if not hasil:
        messagebox.showinfo("Stok", "Barang Kosong")
    else:
        data = "\n".join([f"{nama or 'Belum ada Nama'}\n - {tanggal or 'Belum ada tanggal'}\n - {harga or 'belum ada harga'}" for nama, tanggal, harga in hasil])
        messagebox.showinfo("Daftar Stok", data)
